package com.giftech.githubuser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.giftech.githubuser.databinding.ActivityDetailBinding
import com.giftech.githubuser.model.User

class DetailActivity : AppCompatActivity() {

    companion object{
        const val USER_DATA = "user_data"
    }

    private lateinit var binding: ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val user = intent.getParcelableExtra<User>(USER_DATA) as User

        binding.ivAvatar.setImageResource(user.avatar)
        binding.tvName.text = user.name
        binding.tvUsername.text = user.userName
        binding.tvFollowers.text = user.followers.toString()
        binding.tvFollowing.text = user.following.toString()
        binding.tvCompany.text = user.company
        binding.tvLocation.text = user.location
        binding.tvRepo.text = user.repository.toString()
    }
}