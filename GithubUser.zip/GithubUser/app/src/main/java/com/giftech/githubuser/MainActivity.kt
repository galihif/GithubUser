package com.giftech.githubuser

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.giftech.githubuser.adapter.UserAdapter
import com.giftech.githubuser.databinding.ActivityMainBinding
import com.giftech.githubuser.datasource.UsersData
import com.giftech.githubuser.model.User

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var listUser = arrayListOf<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        listUser.addAll(UsersData.listData)

        showRecycleList()

    }

    private fun showRecycleList() {
        binding.rvUser.layoutManager = LinearLayoutManager(this)
        val listUserAdapter = UserAdapter(listUser)
        binding.rvUser.adapter = listUserAdapter

        listUserAdapter.setOnItemCallback(object : UserAdapter.OnItemClickCallback{
            override fun onItemClicked(data: User) {
                goToDetail(data)
            }

        })
    }

    private fun goToDetail(user: User) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra(DetailActivity.USER_DATA,user)
        startActivity(intent)
    }
}